INSERT INTO `user` (`id`, `age`, `name`) VALUES (1, 20, 'aaa');
INSERT INTO `user` (`id`, `age`, `name`) VALUES (2, 30, 'bbb');
INSERT INTO `user` (`id`, `age`, `name`) VALUES (8, 10, 'AAA');
